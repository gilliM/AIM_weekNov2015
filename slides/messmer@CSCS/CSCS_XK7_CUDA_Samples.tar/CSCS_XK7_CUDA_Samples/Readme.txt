This directory contains sample solutions for the CUDA exercises.

In order to build the samples, make sure you have the correct modules
loaded:

module load cudatoolkit

Use make to build the samples

make

To run the examples, either user aprun directly (after
obtaining an interactive allocation via salloc) or use the
provided slurm scripts.

